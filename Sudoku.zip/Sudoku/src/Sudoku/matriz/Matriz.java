
package Sudoku.matriz;

public class Matriz {
    public int m1[][] = new int[9][9];
    
}   
    
